<div class="container-fluid bg-dark text-white text-center">
    <p>this is footer</p>
</div>
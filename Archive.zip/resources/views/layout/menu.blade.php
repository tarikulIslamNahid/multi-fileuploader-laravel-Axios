<div class="container-fluid bg-dark text-white text-center">
    <p>this is Menu Bar</p>
</div>
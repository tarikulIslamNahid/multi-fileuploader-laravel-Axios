<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    
    <title> <?php echo $__env->yieldContent('title'); ?> </title>
</head>
<body>
    


    <?php echo $__env->yieldContent('content'); ?>


    

    <script type="text/javascript" src=" <?php echo e(asset('js/app.js')); ?>" ></script>
    <script type="text/javascript" src=" <?php echo e(asset('js/custom.js')); ?>" ></script>
</body>
</html><?php /**PATH /Users/tarikukislam/laravel/multi-file-upload-laravel/resources/views/layout/app.blade.php ENDPATH**/ ?>
<div class="container-fluid bg-dark text-white text-center">
    <p>this is Menu Bar</p>
</div><?php /**PATH /Users/tarikukislam/laravel/multi-file-upload-laravel/resources/views/layout/menu.blade.php ENDPATH**/ ?>
<div class="container-fluid bg-dark text-white text-center">
    <p>this is footer</p>
</div><?php /**PATH /Users/tarikukislam/laravel/multi-file-upload-laravel/resources/views/layout/footer.blade.php ENDPATH**/ ?>